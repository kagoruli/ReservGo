
package Vistas;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import javax.swing.JOptionPane;
import Conexion.Conexion;
import javax.swing.table.DefaultTableModel;
/**
 *
 * @author Tania
 */
public class Registro extends javax.swing.JFrame {
   
    private DefaultTableModel modeloTabla;
    /**
     * Creates new form Productos
     */
    public Registro() {        
        initComponents();      
    }
  private String generarUsuario(String nombreCompleto) {
    // Generar usuario basado en el nombre (sin espacios, en minúsculas)
    String usuario = nombreCompleto.toLowerCase().replace(" ", "");
    // Agregar números si es necesario para hacerlo único
    return usuario + (int)(Math.random() * 1000);
}

private boolean registrarUsuario(String usuario, String contraseña, String rol, 
                               String nombreCompleto, String correo, String telefono) throws SQLException {
    
    Connection conn = null;
    try {
        Conexion conexion = new Conexion();
        conn = conexion.getConnection();
        
        if (conn == null) {
            throw new SQLException("No se pudo conectar a la base de datos");
        }
        
        // Insertar en tabla usuarios
        String queryUsuarios = "INSERT INTO usuarios (usuario, contrasena, rol) VALUES (?, ?, ?)";
        PreparedStatement stmtUsuarios = conn.prepareStatement(queryUsuarios);
        stmtUsuarios.setString(1, usuario);
        stmtUsuarios.setString(2, contraseña);
        stmtUsuarios.setString(3, rol);
        stmtUsuarios.executeUpdate();
        
        // Insertar en tabla específica según el rol
        String queryEspecifica;
        if (rol.equals("CLIENTE")) {
            queryEspecifica = "INSERT INTO clientes (usuario, nombre_completo, correo, telefono) VALUES (?, ?, ?, ?)";
        } else {
            queryEspecifica = "INSERT INTO administradores (usuario, nombre_completo, correo, telefono) VALUES (?, ?, ?, ?)";
        }
        
        PreparedStatement stmtEspecifica = conn.prepareStatement(queryEspecifica);
        stmtEspecifica.setString(1, usuario);
        stmtEspecifica.setString(2, nombreCompleto);
        stmtEspecifica.setString(3, correo);
        stmtEspecifica.setString(4, telefono);
        stmtEspecifica.executeUpdate();
        
        return true;
        
    } finally {
        if (conn != null) {
            conn.close();
        }
    }
}

private void limpiarCampos() {
    NombreCompleto.setText("");
    Correo.setText("");
    Telefono.setText("");
    Contraseña.setText("");
    ConfirmarContraseña.setText("");
    jComboBox1.setSelectedIndex(0);
}
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jPanel3 = new javax.swing.JPanel();
        jLabel8 = new javax.swing.JLabel();
        jLabel9 = new javax.swing.JLabel();
        jLabel10 = new javax.swing.JLabel();
        jLabel11 = new javax.swing.JLabel();
        Correo = new javax.swing.JTextField();
        NombreCompleto = new javax.swing.JTextField();
        jLabel12 = new javax.swing.JLabel();
        Telefono = new javax.swing.JTextField();
        Contraseña = new javax.swing.JPasswordField();
        ConfirmarContraseña = new javax.swing.JPasswordField();
        jLabel2 = new javax.swing.JLabel();
        jComboBox1 = new javax.swing.JComboBox<>();
        jPanel2 = new javax.swing.JPanel();
        Aceptar = new javax.swing.JButton();
        Cancelar = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        setTitle("Productos");

        jPanel1.setBackground(new java.awt.Color(234, 252, 255));

        jLabel1.setFont(new java.awt.Font("Haettenschweiler", 0, 24)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(102, 102, 102));
        jLabel1.setText("COMPLETE SU REGISTRO");

        jPanel3.setBackground(new java.awt.Color(182, 218, 218));
        jPanel3.setBorder(javax.swing.BorderFactory.createTitledBorder(null, "Datos:", javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.ABOVE_TOP, new java.awt.Font("Segoe UI Historic", 0, 14), new java.awt.Color(0, 102, 102))); // NOI18N
        jPanel3.setPreferredSize(new java.awt.Dimension(450, 217));

        jLabel8.setText("Nombre Completo:");

        jLabel9.setText("Correo electrónico:");

        jLabel10.setText("Teléfono:");

        jLabel11.setText("Contraseña:");

        Correo.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                CorreoActionPerformed(evt);
            }
        });

        NombreCompleto.setPreferredSize(new java.awt.Dimension(64, 18));
        NombreCompleto.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                NombreCompletoActionPerformed(evt);
            }
        });

        jLabel12.setText("Confirmar contraseña:");

        Telefono.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                TelefonoActionPerformed(evt);
            }
        });

        Contraseña.setText("jPasswordField1");

        ConfirmarContraseña.setText("jPasswordField2");
        ConfirmarContraseña.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ConfirmarContraseñaActionPerformed(evt);
            }
        });

        jLabel2.setText("Tipo usuario");

        jComboBox1.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "CLIENTE", "ADMIN" }));

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addGap(23, 23, 23)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel8, javax.swing.GroupLayout.PREFERRED_SIZE, 138, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel2))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(NombreCompleto, javax.swing.GroupLayout.DEFAULT_SIZE, 293, Short.MAX_VALUE)
                            .addComponent(jComboBox1, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addComponent(jLabel9)
                        .addGap(18, 18, 18)
                        .addComponent(Correo, javax.swing.GroupLayout.PREFERRED_SIZE, 293, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addComponent(jLabel12, javax.swing.GroupLayout.PREFERRED_SIZE, 156, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(ConfirmarContraseña, javax.swing.GroupLayout.PREFERRED_SIZE, 275, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                        .addGroup(jPanel3Layout.createSequentialGroup()
                            .addComponent(jLabel11, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(Contraseña, javax.swing.GroupLayout.PREFERRED_SIZE, 293, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGroup(jPanel3Layout.createSequentialGroup()
                            .addComponent(jLabel10, javax.swing.GroupLayout.PREFERRED_SIZE, 126, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGap(18, 18, 18)
                            .addComponent(Telefono, javax.swing.GroupLayout.PREFERRED_SIZE, 293, javax.swing.GroupLayout.PREFERRED_SIZE))))
                .addGap(542, 542, 542))
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addGap(21, 21, 21)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel2)
                    .addComponent(jComboBox1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(NombreCompleto, javax.swing.GroupLayout.PREFERRED_SIZE, 29, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel8))
                .addGap(18, 18, 18)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(Correo, javax.swing.GroupLayout.PREFERRED_SIZE, 25, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel9))
                .addGap(24, 24, 24)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(Telefono, javax.swing.GroupLayout.PREFERRED_SIZE, 25, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel10))
                .addGap(12, 12, 12)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(Contraseña, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel11))
                .addGap(18, 18, 18)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(ConfirmarContraseña, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel12))
                .addContainerGap(53, Short.MAX_VALUE))
        );

        jPanel2.setBackground(new java.awt.Color(182, 218, 218));
        jPanel2.setBorder(javax.swing.BorderFactory.createEtchedBorder());

        Aceptar.setBackground(new java.awt.Color(149, 173, 179));
        Aceptar.setFont(new java.awt.Font("Segoe UI Light", 1, 12)); // NOI18N
        Aceptar.setForeground(new java.awt.Color(255, 255, 255));
        Aceptar.setText("Aceptar");
        Aceptar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                AceptarActionPerformed(evt);
            }
        });

        Cancelar.setBackground(new java.awt.Color(149, 173, 179));
        Cancelar.setFont(new java.awt.Font("Segoe UI Light", 1, 12)); // NOI18N
        Cancelar.setForeground(new java.awt.Color(255, 255, 255));
        Cancelar.setText("Cancelar");
        Cancelar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                CancelarActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGap(77, 77, 77)
                .addComponent(Aceptar)
                .addGap(162, 162, 162)
                .addComponent(Cancelar)
                .addContainerGap(82, Short.MAX_VALUE))
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGap(16, 16, 16)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(Aceptar)
                    .addComponent(Cancelar))
                .addContainerGap(16, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(208, 208, 208)
                .addComponent(jLabel1))
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(107, 107, 107)
                .addComponent(jPanel3, javax.swing.GroupLayout.PREFERRED_SIZE, 517, javax.swing.GroupLayout.PREFERRED_SIZE))
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(107, 107, 107)
                .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(38, 38, 38)
                .addComponent(jLabel1)
                .addGap(31, 31, 31)
                .addComponent(jPanel3, javax.swing.GroupLayout.PREFERRED_SIZE, 337, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(28, 28, 28)
                .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void CorreoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_CorreoActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_CorreoActionPerformed

    private void NombreCompletoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_NombreCompletoActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_NombreCompletoActionPerformed

    private void AceptarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_AceptarActionPerformed
        // Obtener datos del formulario
    String tipoUsuario = (String) jComboBox1.getSelectedItem();
    String nombreCompleto = NombreCompleto.getText().trim();
    String correo = Correo.getText().trim();
    String telefono = Telefono.getText().trim();
    String contraseña = new String(Contraseña.getPassword());
    String confirmarContraseña = new String(ConfirmarContraseña.getPassword());
    
    // Validaciones
    if (nombreCompleto.isEmpty() || correo.isEmpty() || telefono.isEmpty() || 
        contraseña.isEmpty() || confirmarContraseña.isEmpty()) {
        JOptionPane.showMessageDialog(this, "Por favor complete todos los campos");
        return;
    }
    
    if (!contraseña.equals(confirmarContraseña)) {
        JOptionPane.showMessageDialog(this, "Las contraseñas no coinciden");
        return;
    }
    
    if (contraseña.length() < 6) {
        JOptionPane.showMessageDialog(this, "La contraseña debe tener al menos 6 caracteres");
        return;
    }
    
    // Crear usuario único basado en nombre
    String usuario = generarUsuario(nombreCompleto);
    
    try {
        // Registrar usuario
        if (registrarUsuario(usuario, contraseña, tipoUsuario, nombreCompleto, correo, telefono)) {
            JOptionPane.showMessageDialog(this, 
                "Usuario registrado exitosamente\nUsuario: " + usuario + 
                "\nRecuerde su usuario para iniciar sesión");
            limpiarCampos();
            this.dispose(); // Cerrar ventana de registro
        }
    } catch (Exception e) {
        JOptionPane.showMessageDialog(this, "Error al registrar: " + e.getMessage());
    }
    }//GEN-LAST:event_AceptarActionPerformed

    private void CancelarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_CancelarActionPerformed
            this.dispose(); // Cerrar la ventana
    }//GEN-LAST:event_CancelarActionPerformed

    private void TelefonoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_TelefonoActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_TelefonoActionPerformed

    private void ConfirmarContraseñaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ConfirmarContraseñaActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_ConfirmarContraseñaActionPerformed
   
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton Aceptar;
    private javax.swing.JButton Cancelar;
    private javax.swing.JPasswordField ConfirmarContraseña;
    private javax.swing.JPasswordField Contraseña;
    private javax.swing.JTextField Correo;
    private javax.swing.JTextField NombreCompleto;
    private javax.swing.JTextField Telefono;
    private javax.swing.JComboBox<String> jComboBox1;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    // End of variables declaration//GEN-END:variables
}
