/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package Vistas;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;
import java.util.Date;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.JLabel;
import Conexion.Conexion;
import Controlador.ControladorReserva;
import Vistas.MenuCliente;
import Vistas.Reserva;

import java.awt.Component;
import java.awt.Color;
import javax.swing.JTable;
/**
 *
 * @author santi
 */
public class Disponibilidad extends javax.swing.JFrame {

    /**
     * Creates new form NewJFrame
     */
    public Disponibilidad() {
        initComponents();
        cargarHabitacionesDisponibles();
         this.addWindowFocusListener(new java.awt.event.WindowFocusListener() {
        public void windowGainedFocus(java.awt.event.WindowEvent evt) {
            cargarHabitacionesDisponibles(); // Actualizar cuando regrese a esta ventana
        }
        public void windowLostFocus(java.awt.event.WindowEvent evt) {}
    });
    }

    private void cargarHabitacionesDisponibles() {
    DefaultTableModel modelo = (DefaultTableModel) TablaDisponibilidad.getModel();
    modelo.setRowCount(0); // Limpiar tabla
    
    Connection conn = null;
    try {
        Conexion conexion = new Conexion();
        conn = conexion.getConnection();
        
        // Query que verifica si hay reservas futuras o actuales
        String query = "SELECT h.id, h.numero_habitacion, h.tipo, h.capacidad, h.precio_por_noche, " +
                      "CASE " +
                      "  WHEN EXISTS(" +
                      "    SELECT 1 FROM reservas r " +
                      "    WHERE r.habitacion_id = h.id " +
                      "    AND r.estado IN ('CONFIRMADA', 'PENDIENTE') " +
                      "    AND CURDATE() BETWEEN r.fecha_entrada AND r.fecha_salida" +
                      "  ) THEN 'OCUPADA' " +
                      "  WHEN EXISTS(" +
                      "    SELECT 1 FROM reservas r " +
                      "    WHERE r.habitacion_id = h.id " +
                      "    AND r.estado IN ('CONFIRMADA', 'PENDIENTE') " +
                      "    AND r.fecha_entrada > CURDATE()" +
                      "  ) THEN 'RESERVADA' " +
                      "  ELSE h.estado " +
                      "END as estado_actual, " +
                      "h.descripcion " +
                      "FROM habitaciones h " +
                      "WHERE h.estado != 'MANTENIMIENTO' " +
                      "ORDER BY h.numero_habitacion";
        
        PreparedStatement stmt = conn.prepareStatement(query);
        ResultSet rs = stmt.executeQuery();
        
        while (rs.next()) {
            String estadoActual = rs.getString("estado_actual");
            
            Object[] fila = {
                rs.getInt("id"),
                rs.getString("numero_habitacion"),
                rs.getString("tipo"),
                rs.getInt("capacidad"),
                rs.getDouble("precio_por_noche"),
                estadoActual,
                rs.getString("descripcion")
            };
            modelo.addRow(fila);
        }
        
        if (modelo.getRowCount() == 0) {
            JOptionPane.showMessageDialog(this, "No hay habitaciones registradas");
        }
        
        // Actualizar colores según estado
        configurarColoresTabla();
        
    } catch (SQLException e) {
        JOptionPane.showMessageDialog(this, "Error al cargar habitaciones: " + e.getMessage());
        e.printStackTrace();
    } finally {
        try {
            if (conn != null) conn.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}
    
    private void configurarColoresTabla() {
    TablaDisponibilidad.setDefaultRenderer(Object.class, new DefaultTableCellRenderer() {
        @Override
        public Component getTableCellRendererComponent(JTable table, Object value,
                boolean isSelected, boolean hasFocus, int row, int column) {
            
            Component component = super.getTableCellRendererComponent(table, value, isSelected, hasFocus, row, column);
            
            if (!isSelected) {
                String estado = (String) table.getValueAt(row, 5); // Columna de estado
                
                switch (estado) {
                    case "DISPONIBLE":
                        component.setBackground(new Color(144, 238, 144)); // Verde claro
                        break;
                    case "OCUPADA":
                        component.setBackground(new Color(255, 99, 99)); // Rojo claro
                        break;
                    case "RESERVADA":
                        component.setBackground(new Color(255, 99, 99)); // Rojo claro también
                        break;
                    case "MANTENIMIENTO":
                        component.setBackground(new Color(255, 255, 224)); // Amarillo claro
                        break;
                    default:
                        component.setBackground(Color.WHITE);
                        break;
                }
            }
            
            return component;
        }
    });
}

// Método opcional para filtrar por fechas
private void cargarHabitacionesDisponiblesPorFecha(Date fechaEntrada, Date fechaSalida) {
    DefaultTableModel modelo = (DefaultTableModel) TablaDisponibilidad.getModel();
    modelo.setRowCount(0);
    
    // Usar el método del controlador para obtener habitaciones disponibles por fechas
    List<Object[]> habitacionesDisponibles = ControladorReserva.obtenerHabitacionesDisponibles(fechaEntrada, fechaSalida);
    
    for (Object[] habitacion : habitacionesDisponibles) {
        Object[] fila = {
            habitacion[0], // ID
            habitacion[1], // Número
            habitacion[2], // Tipo
            habitacion[3], // Capacidad
            habitacion[4], // Precio
            "DISPONIBLE",  // Estado
            habitacion[5]  // Descripción
        };
        modelo.addRow(fila);
    }
    
    if (modelo.getRowCount() == 0) {
        JOptionPane.showMessageDialog(this, "No hay habitaciones disponibles para las fechas seleccionadas");
    }
}

// Método para actualizar la tabla
public void actualizarTabla() {
    cargarHabitacionesDisponibles();
}

private void abrirFormularioReserva(int habitacionId, String numeroHabitacion, String tipo, double precio) {
    // Cerrar la ventana actual
    this.dispose();
    
    // Abrir el formulario de reserva
    Reserva formularioReserva = new Reserva();
    formularioReserva.setVisible(true);
    
    // Mostrar información de la habitación seleccionada
    JOptionPane.showMessageDialog(formularioReserva, 
        "Habitación seleccionada:\n\n" +
        "Número: " + numeroHabitacion + "\n" +
        "Tipo: " + tipo + "\n" +
        "Precio: $" + precio + " por noche\n\n" +
        "Complete el formulario para confirmar su reserva.",
        "Habitación Seleccionada", 
        JOptionPane.INFORMATION_MESSAGE);
}

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jPanel3 = new javax.swing.JPanel();
        jScrollPane1 = new javax.swing.JScrollPane();
        TablaDisponibilidad = new javax.swing.JTable();
        jPanel2 = new javax.swing.JPanel();
        Regresar = new javax.swing.JButton();
        Reservar = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);

        jPanel1.setBackground(new java.awt.Color(234, 252, 255));

        jLabel1.setFont(new java.awt.Font("Haettenschweiler", 0, 24)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(102, 102, 102));
        jLabel1.setText("DISPONIBILIDAD DE HABITACIONES");

        jPanel3.setBackground(new java.awt.Color(182, 218, 218));
        jPanel3.setBorder(javax.swing.BorderFactory.createTitledBorder(null, "", javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.ABOVE_TOP, new java.awt.Font("Segoe UI Historic", 0, 14), new java.awt.Color(0, 102, 102))); // NOI18N
        jPanel3.setPreferredSize(new java.awt.Dimension(450, 217));

        TablaDisponibilidad.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null}
            },
            new String [] {
                "ID Habitacion", "Numero", "Tipo", "Capacidad", "Precio", "Estado", "Descripción"
            }
        ));
        jScrollPane1.setViewportView(TablaDisponibilidad);

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel3Layout.createSequentialGroup()
                .addContainerGap(31, Short.MAX_VALUE)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 735, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(28, 28, 28))
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addGap(27, 27, 27)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 295, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(38, Short.MAX_VALUE))
        );

        jPanel2.setBackground(new java.awt.Color(182, 218, 218));
        jPanel2.setBorder(javax.swing.BorderFactory.createEtchedBorder());

        Regresar.setBackground(new java.awt.Color(149, 173, 179));
        Regresar.setFont(new java.awt.Font("Segoe UI Light", 1, 12)); // NOI18N
        Regresar.setForeground(new java.awt.Color(255, 255, 255));
        Regresar.setText("Regresar");
        Regresar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                RegresarActionPerformed(evt);
            }
        });

        Reservar.setBackground(new java.awt.Color(149, 173, 179));
        Reservar.setFont(new java.awt.Font("Segoe UI Light", 1, 12)); // NOI18N
        Reservar.setForeground(new java.awt.Color(255, 255, 255));
        Reservar.setText("Reservar");
        Reservar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ReservarActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGap(188, 188, 188)
                .addComponent(Regresar)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(Reservar)
                .addGap(162, 162, 162))
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGap(16, 16, 16)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(Regresar)
                    .addComponent(Reservar))
                .addContainerGap(16, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(208, 208, 208)
                        .addComponent(jLabel1))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(36, 36, 36)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(jPanel3, javax.swing.GroupLayout.DEFAULT_SIZE, 796, Short.MAX_VALUE)
                            .addComponent(jPanel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))))
                .addContainerGap(59, Short.MAX_VALUE))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(38, 38, 38)
                .addComponent(jLabel1)
                .addGap(18, 18, 18)
                .addComponent(jPanel3, javax.swing.GroupLayout.PREFERRED_SIZE, 362, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(30, 30, 30)
                .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void RegresarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_RegresarActionPerformed
        this.dispose();
        new MenuCliente().setVisible(true);
    }//GEN-LAST:event_RegresarActionPerformed

    private void ReservarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ReservarActionPerformed
       // Verificar si hay una habitación seleccionada
    int filaSeleccionada = TablaDisponibilidad.getSelectedRow();
    
    if (filaSeleccionada == -1) {
        JOptionPane.showMessageDialog(this, "Por favor seleccione una habitación para reservar");
        return;
    }
    
    // Obtener información de la habitación seleccionada
    DefaultTableModel modelo = (DefaultTableModel) TablaDisponibilidad.getModel();
    int habitacionId = (Integer) modelo.getValueAt(filaSeleccionada, 0);
    String numeroHabitacion = (String) modelo.getValueAt(filaSeleccionada, 1);
    String tipo = (String) modelo.getValueAt(filaSeleccionada, 2);
    String estado = (String) modelo.getValueAt(filaSeleccionada, 5);
    double precio = (Double) modelo.getValueAt(filaSeleccionada, 4);
    
    // Verificar el estado de la habitación
    switch (estado) {
        case "OCUPADA":
            JOptionPane.showMessageDialog(this, 
                "La habitación " + numeroHabitacion + " está actualmente ocupada por otro cliente.\n" +
                "Por favor seleccione otra habitación disponible.", 
                "Habitación Ocupada", JOptionPane.WARNING_MESSAGE);
            return;
            
        case "RESERVADA":
            JOptionPane.showMessageDialog(this, 
                "La habitación " + numeroHabitacion + " ya ha sido reservada por otro cliente.\n" +
                "Por favor seleccione otra habitación disponible.", 
                "Habitación Reservada", JOptionPane.WARNING_MESSAGE);
            return;
            
        case "MANTENIMIENTO":
            JOptionPane.showMessageDialog(this, 
                "La habitación " + numeroHabitacion + " está en mantenimiento.\n" +
                "Por favor seleccione otra habitación.", 
                "Habitación No Disponible", JOptionPane.WARNING_MESSAGE);
            return;
    }
    
    // Solo permitir reservar si está disponible
    if ("DISPONIBLE".equals(estado)) {
        String mensaje = "¿Desea reservar esta habitación?\n\n" +
                        "Habitación: " + numeroHabitacion + "\n" +
                        "Tipo: " + tipo + "\n" +
                        "Precio por noche: $" + precio + "\n\n" +
                        "Será redirigido al formulario de reserva.";
        
        int confirmacion = JOptionPane.showConfirmDialog(this, mensaje, 
            "Confirmar Selección", JOptionPane.YES_NO_OPTION);
        
        if (confirmacion == JOptionPane.YES_OPTION) {
            this.dispose();
            abrirFormularioReserva(habitacionId, numeroHabitacion, tipo, precio);
        }
    }

    }//GEN-LAST:event_ReservarActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Disponibilidad.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Disponibilidad.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Disponibilidad.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Disponibilidad.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Disponibilidad().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton Regresar;
    private javax.swing.JButton Reservar;
    private javax.swing.JTable TablaDisponibilidad;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JScrollPane jScrollPane1;
    // End of variables declaration//GEN-END:variables
}
