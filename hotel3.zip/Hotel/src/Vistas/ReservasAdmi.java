/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package Vistas;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.JLabel;
import Conexion.Conexion;
import Vistas.MenuAdmi;
/**
 *
 * @author santi
 */
public class ReservasAdmi extends javax.swing.JFrame {

    /**
     * Creates new form ReservasAdmi
     */
    public ReservasAdmi() {
        initComponents();
        cargarReservas();
    }
    private void cargarReservas() {
    DefaultTableModel modelo = (DefaultTableModel) TablaHabitacionReservacion.getModel();
    modelo.setRowCount(0); // Limpiar tabla
    
    Connection conn = null;
    try {
        Conexion conexion = new Conexion();
        conn = conexion.getConnection();
        
        // Query que une las tablas de reservas y clientes para obtener todos los datos
        String query = "SELECT r.id, r.usuario_cliente, r.nombre_cliente, r.telefono, " +
                      "r.fecha_entrada, r.fecha_salida, r.referencia_pago, r.estado, r.fecha_reserva " +
                      "FROM reservas r " +
                      "ORDER BY r.fecha_reserva DESC";
        
        PreparedStatement stmt = conn.prepareStatement(query);
        ResultSet rs = stmt.executeQuery();
        
        SimpleDateFormat formatoFecha = new SimpleDateFormat("dd/MM/yyyy");
        SimpleDateFormat formatoFechaHora = new SimpleDateFormat("dd/MM/yyyy HH:mm");
        
        while (rs.next()) {
            Object[] fila = {
                rs.getInt("id"),
                rs.getString("usuario_cliente"),
                rs.getString("nombre_cliente"),
                rs.getString("telefono"),
                formatoFecha.format(rs.getDate("fecha_entrada")),
                formatoFecha.format(rs.getDate("fecha_salida")),
                rs.getString("referencia_pago"),
                rs.getString("estado"),
                formatoFechaHora.format(rs.getTimestamp("fecha_reserva"))
            };
            modelo.addRow(fila);
        }
        
        if (modelo.getRowCount() == 0) {
            JOptionPane.showMessageDialog(this, "No hay reservas registradas");
        } else {
            JOptionPane.showMessageDialog(this, "Se cargaron " + modelo.getRowCount() + " reservas");
        }
        
    } catch (SQLException e) {
        JOptionPane.showMessageDialog(this, "Error al cargar reservas: " + e.getMessage());
        e.printStackTrace();
    } finally {
        try {
            if (conn != null) conn.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}

private void editarReserva() {
    int filaSeleccionada = TablaHabitacionReservacion.getSelectedRow();
    
    if (filaSeleccionada == -1) {
        JOptionPane.showMessageDialog(this, "Por favor seleccione una reserva para gestionar");
        return;
    }
    
    DefaultTableModel modelo = (DefaultTableModel) TablaHabitacionReservacion.getModel();
    int id = (Integer) modelo.getValueAt(filaSeleccionada, 0);
    String cliente = (String) modelo.getValueAt(filaSeleccionada, 1);
    String nombre = (String) modelo.getValueAt(filaSeleccionada, 2);
    String estadoActual = (String) modelo.getValueAt(filaSeleccionada, 7);
    String referencia = (String) modelo.getValueAt(filaSeleccionada, 6);
    
    // Mostrar opciones de gestión
    String[] opciones = {"Cambiar Estado", "Ver Detalles", "Eliminar Reserva", "Cancelar"};
    int opcion = JOptionPane.showOptionDialog(this,
        "Reserva: " + referencia + "\nCliente: " + nombre + "\nEstado: " + estadoActual,
        "Gestionar Reserva",
        JOptionPane.DEFAULT_OPTION,
        JOptionPane.INFORMATION_MESSAGE,
        null, opciones, opciones[0]);
    
    switch (opcion) {
        case 0: // Cambiar Estado
            cambiarEstadoReserva(id, estadoActual);
            break;
        case 1: // Ver Detalles
            mostrarDetallesReserva(id);
            break;
        case 2: // Eliminar
            eliminarReserva(id, nombre, referencia);
            break;
        default: // Cancelar
            break;
    }
}

private void cambiarEstadoReserva(int id, String estadoActual) {
    String[] estados = {"PENDIENTE", "CONFIRMADA", "CANCELADA"};
    String nuevoEstado = (String) JOptionPane.showInputDialog(this,
        "Estado actual: " + estadoActual + "\nSeleccione el nuevo estado:",
        "Cambiar Estado",
        JOptionPane.QUESTION_MESSAGE,
        null, estados, estadoActual);
    
    if (nuevoEstado != null && !nuevoEstado.equals(estadoActual)) {
        if (actualizarEstadoReserva(id, nuevoEstado)) {
            JOptionPane.showMessageDialog(this, "Estado actualizado a: " + nuevoEstado);
            cargarReservas(); // Recargar tabla
        }
    }
}

private boolean actualizarEstadoReserva(int id, String nuevoEstado) {
    Connection conn = null;
    try {
        Conexion conexion = new Conexion();
        conn = conexion.getConnection();
        
        String query = "UPDATE reservas SET estado = ? WHERE id = ?";
        PreparedStatement stmt = conn.prepareStatement(query);
        stmt.setString(1, nuevoEstado);
        stmt.setInt(2, id);
        
        int rowsAffected = stmt.executeUpdate();
        return rowsAffected > 0;
        
    } catch (SQLException e) {
        JOptionPane.showMessageDialog(this, "Error al actualizar estado: " + e.getMessage());
        return false;
    } finally {
        try {
            if (conn != null) conn.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}

private void mostrarDetallesReserva(int id) {
    Connection conn = null;
    try {
        Conexion conexion = new Conexion();
        conn = conexion.getConnection();
        
        String query = "SELECT * FROM reservas WHERE id = ?";
        PreparedStatement stmt = conn.prepareStatement(query);
        stmt.setInt(1, id);
        ResultSet rs = stmt.executeQuery();
        
        if (rs.next()) {
            SimpleDateFormat formatoCompleto = new SimpleDateFormat("dd/MM/yyyy HH:mm:ss");
            
            String detalles = "═══════════════════════════════════════\n" +
                            "              DETALLES DE RESERVA\n" +
                            "═══════════════════════════════════════\n\n" +
                            "ID Reserva: " + rs.getInt("id") + "\n" +
                            "Usuario Cliente: " + rs.getString("usuario_cliente") + "\n" +
                            "Nombre: " + rs.getString("nombre_cliente") + "\n" +
                            "Teléfono: " + rs.getString("telefono") + "\n" +
                            "Fecha Entrada: " + formatoCompleto.format(rs.getDate("fecha_entrada")) + "\n" +
                            "Fecha Salida: " + formatoCompleto.format(rs.getDate("fecha_salida")) + "\n" +
                            "Referencia Pago: " + rs.getString("referencia_pago") + "\n" +
                            "Estado: " + rs.getString("estado") + "\n" +
                            "Fecha Reserva: " + formatoCompleto.format(rs.getTimestamp("fecha_reserva")) + "\n" +
                            "═══════════════════════════════════════";
            
            JOptionPane.showMessageDialog(this, detalles, "Detalles de Reserva", JOptionPane.INFORMATION_MESSAGE);
        }
        
    } catch (SQLException e) {
        JOptionPane.showMessageDialog(this, "Error al obtener detalles: " + e.getMessage());
    } finally {
        try {
            if (conn != null) conn.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}

private void eliminarReserva(int id, String nombreCliente, String referencia) {
    int confirmacion = JOptionPane.showConfirmDialog(this,
        "¿Está seguro de eliminar la reserva?\n" +
        "Cliente: " + nombreCliente + "\n" +
        "Referencia: " + referencia + "\n\n" +
        "Esta acción no se puede deshacer.",
        "Confirmar Eliminación",
        JOptionPane.YES_NO_OPTION,
        JOptionPane.WARNING_MESSAGE);
    
    if (confirmacion == JOptionPane.YES_OPTION) {
        Connection conn = null;
        try {
            Conexion conexion = new Conexion();
            conn = conexion.getConnection();
            
            String query = "DELETE FROM reservas WHERE id = ?";
            PreparedStatement stmt = conn.prepareStatement(query);
            stmt.setInt(1, id);
            
            int rowsAffected = stmt.executeUpdate();
            if (rowsAffected > 0) {
                JOptionPane.showMessageDialog(this, "Reserva eliminada correctamente");
                cargarReservas(); // Recargar tabla
            } else {
                JOptionPane.showMessageDialog(this, "No se pudo eliminar la reserva");
            }
            
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(this, "Error al eliminar reserva: " + e.getMessage());
        } finally {
            try {
                if (conn != null) conn.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
    }
}
    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jPanel3 = new javax.swing.JPanel();
        jScrollPane1 = new javax.swing.JScrollPane();
        TablaHabitacionReservacion = new javax.swing.JTable();
        jPanel2 = new javax.swing.JPanel();
        Regresar1 = new javax.swing.JButton();
        Reservar = new javax.swing.JButton();
        Regresar2 = new javax.swing.JButton();
        Regresar3 = new javax.swing.JButton();
        Regresar4 = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);

        jPanel1.setBackground(new java.awt.Color(234, 252, 255));

        jLabel1.setFont(new java.awt.Font("Haettenschweiler", 0, 24)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(102, 102, 102));
        jLabel1.setText("RESERVAS");

        jPanel3.setBackground(new java.awt.Color(182, 218, 218));
        jPanel3.setBorder(javax.swing.BorderFactory.createTitledBorder(null, "", javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.ABOVE_TOP, new java.awt.Font("Segoe UI Historic", 0, 14), new java.awt.Color(0, 102, 102))); // NOI18N
        jPanel3.setPreferredSize(new java.awt.Dimension(450, 217));

        TablaHabitacionReservacion.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null}
            },
            new String [] {
                "ID Reserva", "Cliente", "Nombre", "Telefono", "Fecha Inicio", "Fecha Salida", "Referencia", "Estado", "Fecha Reserva"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                true, true, true, false, true, true, true, true, true
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        jScrollPane1.setViewportView(TablaHabitacionReservacion);

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel3Layout.createSequentialGroup()
                .addContainerGap(20, Short.MAX_VALUE)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 913, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(27, 27, 27))
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addGap(37, 37, 37)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 285, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(38, Short.MAX_VALUE))
        );

        jPanel2.setBackground(new java.awt.Color(182, 218, 218));
        jPanel2.setBorder(javax.swing.BorderFactory.createEtchedBorder());

        Regresar1.setBackground(new java.awt.Color(149, 173, 179));
        Regresar1.setFont(new java.awt.Font("Segoe UI Light", 1, 12)); // NOI18N
        Regresar1.setForeground(new java.awt.Color(255, 255, 255));
        Regresar1.setText("Mostrar");
        Regresar1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                Regresar1ActionPerformed(evt);
            }
        });

        Reservar.setBackground(new java.awt.Color(149, 173, 179));
        Reservar.setFont(new java.awt.Font("Segoe UI Light", 1, 12)); // NOI18N
        Reservar.setForeground(new java.awt.Color(255, 255, 255));
        Reservar.setText("Actualizar");
        Reservar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ReservarActionPerformed(evt);
            }
        });

        Regresar2.setBackground(new java.awt.Color(149, 173, 179));
        Regresar2.setFont(new java.awt.Font("Segoe UI Light", 1, 12)); // NOI18N
        Regresar2.setForeground(new java.awt.Color(255, 255, 255));
        Regresar2.setText("Editar");
        Regresar2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                Regresar2ActionPerformed(evt);
            }
        });

        Regresar3.setBackground(new java.awt.Color(149, 173, 179));
        Regresar3.setFont(new java.awt.Font("Segoe UI Light", 1, 12)); // NOI18N
        Regresar3.setForeground(new java.awt.Color(255, 255, 255));
        Regresar3.setText("Añadir");
        Regresar3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                Regresar3ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGap(83, 83, 83)
                .addComponent(Regresar3)
                .addGap(118, 118, 118)
                .addComponent(Regresar1)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(Regresar2)
                .addGap(140, 140, 140)
                .addComponent(Reservar)
                .addGap(103, 103, 103))
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGap(16, 16, 16)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(Regresar1)
                    .addComponent(Reservar)
                    .addComponent(Regresar2)
                    .addComponent(Regresar3))
                .addContainerGap(16, Short.MAX_VALUE))
        );

        Regresar4.setBackground(new java.awt.Color(149, 173, 179));
        Regresar4.setFont(new java.awt.Font("Segoe UI Light", 1, 12)); // NOI18N
        Regresar4.setForeground(new java.awt.Color(255, 255, 255));
        Regresar4.setText("Regresar");
        Regresar4.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                Regresar4ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(420, 420, 420)
                        .addComponent(jLabel1))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(36, 36, 36)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(Regresar4)
                            .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                .addComponent(jPanel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(jPanel3, javax.swing.GroupLayout.DEFAULT_SIZE, 962, Short.MAX_VALUE)))))
                .addContainerGap(41, Short.MAX_VALUE))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(27, 27, 27)
                .addComponent(jLabel1)
                .addGap(29, 29, 29)
                .addComponent(jPanel3, javax.swing.GroupLayout.PREFERRED_SIZE, 362, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(33, 33, 33)
                .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 51, Short.MAX_VALUE)
                .addComponent(Regresar4)
                .addGap(37, 37, 37))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void Regresar1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Regresar1ActionPerformed
        cargarReservas();
    }//GEN-LAST:event_Regresar1ActionPerformed

    private void ReservarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ReservarActionPerformed
        cargarReservas();
        JOptionPane.showMessageDialog(this, "Tabla actualizada correctamente");
    }//GEN-LAST:event_ReservarActionPerformed

    private void Regresar2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Regresar2ActionPerformed
        editarReserva();
    }//GEN-LAST:event_Regresar2ActionPerformed

    private void Regresar3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Regresar3ActionPerformed
        JOptionPane.showMessageDialog(this, "Para crear una nueva reserva, use el sistema de clientes");
        new InicioSesion().setVisible(true);
    }//GEN-LAST:event_Regresar3ActionPerformed

    private void Regresar4ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Regresar4ActionPerformed
        this.dispose();
        new MenuAdmi().setVisible(true);
    }//GEN-LAST:event_Regresar4ActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(ReservasAdmi.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(ReservasAdmi.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(ReservasAdmi.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(ReservasAdmi.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new ReservasAdmi().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton Regresar1;
    private javax.swing.JButton Regresar2;
    private javax.swing.JButton Regresar3;
    private javax.swing.JButton Regresar4;
    private javax.swing.JButton Reservar;
    private javax.swing.JTable TablaHabitacionReservacion;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JScrollPane jScrollPane1;
    // End of variables declaration//GEN-END:variables
}
