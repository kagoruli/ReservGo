/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package Vistas;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.JTextField;
import javax.swing.JLabel;
import javax.swing.JPanel;
import java.awt.GridLayout;
import Conexion.Conexion;
import Vistas.MenuAdmi;
import Vistas.Registro;
/**
 *
 * @author santi
 */
public class Clientes extends javax.swing.JFrame {

    /**
     * Creates new form Clientes
     */
    public Clientes() {
        initComponents();
        cargarClientes();
    }
private void cargarClientes() {
    DefaultTableModel modelo = (DefaultTableModel) TableClientes.getModel();
    modelo.setRowCount(0); // Limpiar tabla
    
    Connection conn = null;
    try {
        Conexion conexion = new Conexion();
        conn = conexion.getConnection();
        
        String query = "SELECT c.id, c.usuario, c.nombre_completo, c.correo, c.telefono, c.fecha_registro " +
                      "FROM clientes c ORDER BY c.fecha_registro DESC";
        
        PreparedStatement stmt = conn.prepareStatement(query);
        ResultSet rs = stmt.executeQuery();
        
        SimpleDateFormat formatoFecha = new SimpleDateFormat("dd/MM/yyyy");
        
        while (rs.next()) {
            Object[] fila = {
                rs.getInt("id"),
                rs.getString("usuario"),
                rs.getString("nombre_completo"),
                rs.getString("correo"),
                rs.getString("telefono"),
                formatoFecha.format(rs.getTimestamp("fecha_registro"))
            };
            modelo.addRow(fila);
        }
        
        if (modelo.getRowCount() == 0) {
            JOptionPane.showMessageDialog(this, "No hay clientes registrados");
        } else {
            JOptionPane.showMessageDialog(this, "Se cargaron " + modelo.getRowCount() + " clientes");
        }
        
    } catch (SQLException e) {
        JOptionPane.showMessageDialog(this, "Error al cargar clientes: " + e.getMessage());
        e.printStackTrace();
    } finally {
        try {
            if (conn != null) conn.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}

private void editarCliente() {
    int filaSeleccionada = TableClientes.getSelectedRow();
    
    if (filaSeleccionada == -1) {
        JOptionPane.showMessageDialog(this, "Por favor seleccione un cliente para editar");
        return;
    }
    
    // Obtener datos de la fila seleccionada
    DefaultTableModel modelo = (DefaultTableModel) TableClientes.getModel();
    int id = (Integer) modelo.getValueAt(filaSeleccionada, 0);
    String usuario = (String) modelo.getValueAt(filaSeleccionada, 1);
    String nombre = (String) modelo.getValueAt(filaSeleccionada, 2);
    String correo = (String) modelo.getValueAt(filaSeleccionada, 3);
    String telefono = (String) modelo.getValueAt(filaSeleccionada, 4);
    
    // Mostrar diálogo de edición
    mostrarDialogoEdicion(id, usuario, nombre, correo, telefono);
}

private void mostrarDialogoEdicion(int id, String usuario, String nombre, String correo, String telefono) {
    JTextField campoNombre = new JTextField(nombre);
    JTextField campoCorreo = new JTextField(correo);
    JTextField campoTelefono = new JTextField(telefono);
    
    JPanel panel = new JPanel(new GridLayout(3, 2, 5, 5));
    panel.add(new JLabel("Nombre:"));
    panel.add(campoNombre);
    panel.add(new JLabel("Correo:"));
    panel.add(campoCorreo);
    panel.add(new JLabel("Teléfono:"));
    panel.add(campoTelefono);
    
    int resultado = JOptionPane.showConfirmDialog(this, panel, 
        "Editar Cliente: " + usuario, JOptionPane.OK_CANCEL_OPTION);
    
    if (resultado == JOptionPane.OK_OPTION) {
        String nuevoNombre = campoNombre.getText().trim();
        String nuevoCorreo = campoCorreo.getText().trim();
        String nuevoTelefono = campoTelefono.getText().trim();
        
        if (nuevoNombre.isEmpty() || nuevoCorreo.isEmpty() || nuevoTelefono.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Todos los campos son obligatorios");
            return;
        }
        
        if (actualizarCliente(id, nuevoNombre, nuevoCorreo, nuevoTelefono)) {
            JOptionPane.showMessageDialog(this, "Cliente actualizado correctamente");
            cargarClientes(); // Recargar tabla
        }
    }
}

private boolean actualizarCliente(int id, String nombre, String correo, String telefono) {
    Connection conn = null;
    try {
        Conexion conexion = new Conexion();
        conn = conexion.getConnection();
        
        String query = "UPDATE clientes SET nombre_completo = ?, correo = ?, telefono = ? WHERE id = ?";
        PreparedStatement stmt = conn.prepareStatement(query);
        stmt.setString(1, nombre);
        stmt.setString(2, correo);
        stmt.setString(3, telefono);
        stmt.setInt(4, id);
        
        int rowsAffected = stmt.executeUpdate();
        return rowsAffected > 0;
        
    } catch (SQLException e) {
        JOptionPane.showMessageDialog(this, "Error al actualizar cliente: " + e.getMessage());
        return false;
    } finally {
        try {
            if (conn != null) conn.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}
    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jPanel3 = new javax.swing.JPanel();
        jScrollPane1 = new javax.swing.JScrollPane();
        TableClientes = new javax.swing.JTable();
        jPanel2 = new javax.swing.JPanel();
        Regresar1 = new javax.swing.JButton();
        Reservar = new javax.swing.JButton();
        Regresar2 = new javax.swing.JButton();
        Regresar3 = new javax.swing.JButton();
        Regresar4 = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);

        jPanel1.setBackground(new java.awt.Color(234, 252, 255));

        jLabel1.setFont(new java.awt.Font("Haettenschweiler", 0, 24)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(102, 102, 102));
        jLabel1.setText("CLIENTES");

        jPanel3.setBackground(new java.awt.Color(182, 218, 218));
        jPanel3.setBorder(javax.swing.BorderFactory.createTitledBorder(null, "", javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.ABOVE_TOP, new java.awt.Font("Segoe UI Historic", 0, 14), new java.awt.Color(0, 102, 102))); // NOI18N
        jPanel3.setPreferredSize(new java.awt.Dimension(450, 217));

        TableClientes.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null}
            },
            new String [] {
                "ID Cliente", "Usuario", "Nombre completo", "Correo eléctronico", "Telefono", "Fecha Registro"
            }
        ));
        jScrollPane1.setViewportView(TableClientes);

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addGap(34, 34, 34)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 878, Short.MAX_VALUE)
                .addGap(48, 48, 48))
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addGap(35, 35, 35)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 281, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(44, Short.MAX_VALUE))
        );

        jPanel2.setBackground(new java.awt.Color(182, 218, 218));
        jPanel2.setBorder(javax.swing.BorderFactory.createEtchedBorder());

        Regresar1.setBackground(new java.awt.Color(149, 173, 179));
        Regresar1.setFont(new java.awt.Font("Segoe UI Light", 1, 12)); // NOI18N
        Regresar1.setForeground(new java.awt.Color(255, 255, 255));
        Regresar1.setText("Mostrar");
        Regresar1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                Regresar1ActionPerformed(evt);
            }
        });

        Reservar.setBackground(new java.awt.Color(149, 173, 179));
        Reservar.setFont(new java.awt.Font("Segoe UI Light", 1, 12)); // NOI18N
        Reservar.setForeground(new java.awt.Color(255, 255, 255));
        Reservar.setText("Actualizar");
        Reservar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ReservarActionPerformed(evt);
            }
        });

        Regresar2.setBackground(new java.awt.Color(149, 173, 179));
        Regresar2.setFont(new java.awt.Font("Segoe UI Light", 1, 12)); // NOI18N
        Regresar2.setForeground(new java.awt.Color(255, 255, 255));
        Regresar2.setText("Editar");
        Regresar2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                Regresar2ActionPerformed(evt);
            }
        });

        Regresar3.setBackground(new java.awt.Color(149, 173, 179));
        Regresar3.setFont(new java.awt.Font("Segoe UI Light", 1, 12)); // NOI18N
        Regresar3.setForeground(new java.awt.Color(255, 255, 255));
        Regresar3.setText("Añadir");
        Regresar3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                Regresar3ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGap(83, 83, 83)
                .addComponent(Regresar3)
                .addGap(118, 118, 118)
                .addComponent(Regresar1)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(Regresar2)
                .addGap(140, 140, 140)
                .addComponent(Reservar)
                .addGap(103, 103, 103))
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGap(16, 16, 16)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(Regresar1)
                    .addComponent(Reservar)
                    .addComponent(Regresar2)
                    .addComponent(Regresar3))
                .addContainerGap(16, Short.MAX_VALUE))
        );

        Regresar4.setBackground(new java.awt.Color(149, 173, 179));
        Regresar4.setFont(new java.awt.Font("Segoe UI Light", 1, 12)); // NOI18N
        Regresar4.setForeground(new java.awt.Color(255, 255, 255));
        Regresar4.setText("Regresar");
        Regresar4.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                Regresar4ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(420, 420, 420)
                        .addComponent(jLabel1))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(36, 36, 36)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(Regresar4)
                            .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                .addComponent(jPanel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(jPanel3, javax.swing.GroupLayout.DEFAULT_SIZE, 962, Short.MAX_VALUE)))))
                .addContainerGap(41, Short.MAX_VALUE))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(27, 27, 27)
                .addComponent(jLabel1)
                .addGap(29, 29, 29)
                .addComponent(jPanel3, javax.swing.GroupLayout.PREFERRED_SIZE, 362, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(33, 33, 33)
                .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 46, Short.MAX_VALUE)
                .addComponent(Regresar4)
                .addGap(37, 37, 37))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void Regresar1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Regresar1ActionPerformed
            cargarClientes();
    }//GEN-LAST:event_Regresar1ActionPerformed

    private void ReservarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ReservarActionPerformed
        cargarClientes();
        JOptionPane.showMessageDialog(this, "Tabla actualizada correctamente");
    }//GEN-LAST:event_ReservarActionPerformed

    private void Regresar2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Regresar2ActionPerformed
        editarCliente();
    }//GEN-LAST:event_Regresar2ActionPerformed

    private void Regresar3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Regresar3ActionPerformed
        new Registro().setVisible(true);
    }//GEN-LAST:event_Regresar3ActionPerformed

    private void Regresar4ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Regresar4ActionPerformed
        this.dispose();
        new MenuAdmi().setVisible(true);
    }//GEN-LAST:event_Regresar4ActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Clientes.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Clientes.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Clientes.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Clientes.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Clientes().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton Regresar1;
    private javax.swing.JButton Regresar2;
    private javax.swing.JButton Regresar3;
    private javax.swing.JButton Regresar4;
    private javax.swing.JButton Reservar;
    private javax.swing.JTable TableClientes;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JScrollPane jScrollPane1;
    // End of variables declaration//GEN-END:variables
}
