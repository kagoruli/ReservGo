package Modelos;

import Conexion.Conexion;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.security.MessageDigest;
import static Principal.App.conexion;
import java.security.NoSuchAlgorithmException;

public class Login {

    private static String nombre;
    private static String contrasena;
    private String rol;

    public Login(String usuario, String contrasena, String rol) {
        this.nombre = usuario;
        this.contrasena = contrasena;
        this.rol = rol;
    }

    public static String getNombre() {
        return nombre;
    }

    public static void setNombre(String nombre) {
        Login.nombre = nombre;
    }

    public static String getContrasena() {
        return contrasena;
    }

    public static void setContrasena(String contrasena) {
        Login.contrasena = contrasena;
    }

    public boolean validarRegistro() throws SQLException {
    String query = "SELECT * FROM usuarios WHERE usuario = ? AND contrasena = ? AND rol = ?";
    
    try (Connection conn = Conexion.getConnection();
         PreparedStatement stmt = conn.prepareStatement(query)) {
        
        stmt.setString(1, this.nombre);
        stmt.setString(2, this.contrasena); 
        stmt.setString(3, this.rol);
        
        ResultSet rs = stmt.executeQuery();
        return rs.next(); // Retorna true si encuentra coincidencia
    }
}

    public static String encriptar(String text) {
        try {
            MessageDigest md = MessageDigest.getInstance("SHA-256");
            byte[] hashBytes = md.digest(text.getBytes());
            StringBuilder sb = new StringBuilder();
            for (byte b : hashBytes) {
                sb.append(String.format("%02x", b));
            }

            return sb.toString();
        } catch (NoSuchAlgorithmException e) {
            throw new RuntimeException(e);
        }
    }

}
