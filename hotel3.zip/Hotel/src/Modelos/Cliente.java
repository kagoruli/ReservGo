/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Modelos;


import java.sql.Timestamp;
import java.util.Date;

// Cliente.java
public class Cliente {
    private int clienteId;
    private String nombre;
    private String documentoIdentidad;
    private String contacto;
    private Timestamp fechaRegistro;
    
    public Cliente() {}
    
    public Cliente(String nombre, String documentoIdentidad, String contacto) {
        this.nombre = nombre;
        this.documentoIdentidad = documentoIdentidad;
        this.contacto = contacto;
    }
    
    // Getters y setters
    public int getClienteId() {
        return clienteId;
    }
    
    public void setClienteId(int clienteId) {
        this.clienteId = clienteId;
    }
    
    public String getNombre() {
        return nombre;
    }
    
    public void setNombre(String nombre) {
        this.nombre = nombre;
    }
    
    public String getDocumentoIdentidad() {
        return documentoIdentidad;
    }
    
    public void setDocumentoIdentidad(String documentoIdentidad) {
        this.documentoIdentidad = documentoIdentidad;
    }
    
    public String getContacto() {
        return contacto;
    }
    
    public void setContacto(String contacto) {
        this.contacto = contacto;
    }
    
    public Timestamp getFechaRegistro() {
        return fechaRegistro;
    }
    
    public void setFechaRegistro(Timestamp fechaRegistro) {
        this.fechaRegistro = fechaRegistro;
    }
}
