/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Modelos;

import java.sql.Timestamp;
import java.util.Date;

/**
 *
 * @author santi
 */

public class Reserva {
    private int id;
    private String usuarioCliente;
    private String nombreCliente;
    private String telefono;
    private Date fechaEntrada;
    private Date fechaSalida;
    private String referenciaPago;
    private String estado;
    private Timestamp fechaReserva;
    
    public Reserva() {}
    
    public Reserva(String usuarioCliente, String nombreCliente, String telefono, 
                   Date fechaEntrada, Date fechaSalida, String referenciaPago) {
        this.usuarioCliente = usuarioCliente;
        this.nombreCliente = nombreCliente;
        this.telefono = telefono;
        this.fechaEntrada = fechaEntrada;
        this.fechaSalida = fechaSalida;
        this.referenciaPago = referenciaPago;
        this.estado = "PENDIENTE";
    }
        
    // Getters y setters
    public int getId() { return id; }
    public void setId(int id) { this.id = id; }
    
    public String getUsuarioCliente() { return usuarioCliente; }
    public void setUsuarioCliente(String usuarioCliente) { this.usuarioCliente = usuarioCliente; }
    
    public String getNombreCliente() { return nombreCliente; }
    public void setNombreCliente(String nombreCliente) { this.nombreCliente = nombreCliente; }
    
    public String getTelefono() { return telefono; }
    public void setTelefono(String telefono) { this.telefono = telefono; }
    
    public Date getFechaEntrada() { return fechaEntrada; }
    public void setFechaEntrada(Date fechaEntrada) { this.fechaEntrada = fechaEntrada; }
    
    public Date getFechaSalida() { return fechaSalida; }
    public void setFechaSalida(Date fechaSalida) { this.fechaSalida = fechaSalida; }
    
    public String getReferenciaPago() { return referenciaPago; }
    public void setReferenciaPago(String referenciaPago) { this.referenciaPago = referenciaPago; }
    
    public String getEstado() { return estado; }
    public void setEstado(String estado) { this.estado = estado; }
    
    public Timestamp getFechaReserva() { return fechaReserva; }
    public void setFechaReserva(Timestamp fechaReserva) { this.fechaReserva = fechaReserva; }
}