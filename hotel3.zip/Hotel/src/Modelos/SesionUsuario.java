/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Modelos;

public class SesionUsuario {
    private static String usuarioActual;
    private static String rolActual;
    
    public static void iniciarSesion(String usuario, String rol) {
        usuarioActual = usuario;
        rolActual = rol;
    }
    
    public static String getUsuarioActual() {
        return usuarioActual;
    }
    
    public static String getRolActual() {
        return rolActual;
    }
    
    public static void cerrarSesion() {
        usuarioActual = null;
        rolActual = null;
    }
    
    public static boolean haySesionActiva() {
        return usuarioActual != null && rolActual != null;
    }
}
