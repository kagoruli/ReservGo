/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Modelos;

import java.sql.Timestamp;

/**
 *
 * @author santi
 */
public class Pago {
    private int pagoId;
    private int reservaId;
    private double monto;
    private String metodoPago;
    private String codigoReferencia;
    private String estadoPago;
    private Timestamp fechaPago;
    
    public Pago() {}
    
    public Pago(int reservaId, double monto, String metodoPago, String codigoReferencia, String estadoPago) {
        this.reservaId = reservaId;
        this.monto = monto;
        this.metodoPago = metodoPago;
        this.codigoReferencia = codigoReferencia;
        this.estadoPago = estadoPago;
    }
    
     public int getPagoId() {
        return pagoId;
    }
    
    public void setPagoId(int pagoId) {
        this.pagoId = pagoId;
    }
    
    public int getReservaId() {
        return reservaId;
    }
    
    public void setReservaId(int reservaId) {
        this.reservaId = reservaId;
    }
    
    public double getMonto() {
        return monto;
    }
    
    public void setMonto(double monto) {
        this.monto = monto;
    }
    
    public String getMetodoPago() {
        return metodoPago;
    }
    
    public void setMetodoPago(String metodoPago) {
        this.metodoPago = metodoPago;
    }
    
    public String getCodigoReferencia() {
        return codigoReferencia;
    }
    
    public void setCodigoReferencia(String codigoReferencia) {
        this.codigoReferencia = codigoReferencia;
    }
    
    public String getEstadoPago() {
        return estadoPago;
    }
    
    public void setEstadoPago(String estadoPago) {
        this.estadoPago = estadoPago;
    }
    
    public Timestamp getFechaPago() {
        return fechaPago;
    }
    
    public void setFechaPago(Timestamp fechaPago) {
        this.fechaPago = fechaPago;
    }
}


