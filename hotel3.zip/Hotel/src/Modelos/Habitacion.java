/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Modelos;

/**
 *
 * @author santi
 */
public class Habitacion {
    private int habitacionId;
    private String tipoHabitacion;
    private String numeroHabitacion;
    private int capacidad;
    private double precioBase;
    private String estado;
    
    public Habitacion() {}
    
    public Habitacion(String tipoHabitacion, String numeroHabitacion, int capacidad, double precioBase, String estado) {
        this.tipoHabitacion = tipoHabitacion;
        this.numeroHabitacion = numeroHabitacion;
        this.capacidad = capacidad;
        this.precioBase = precioBase;
        this.estado = estado;
    }
    
    // Getters y setters
    public int getHabitacionId() {
        return habitacionId;
    }
    
    public void setHabitacionId(int habitacionId) {
        this.habitacionId = habitacionId;
    }
    
    public String getTipoHabitacion() {
        return tipoHabitacion;
    }
    
    public void setTipoHabitacion(String tipoHabitacion) {
        this.tipoHabitacion = tipoHabitacion;
    }
    
    public String getNumeroHabitacion() {
        return numeroHabitacion;
    }
    
    public void setNumeroHabitacion(String numeroHabitacion) {
        this.numeroHabitacion = numeroHabitacion;
    }
    
    public int getCapacidad() {
        return capacidad;
    }
    
    public void setCapacidad(int capacidad) {
        this.capacidad = capacidad;
    }
    
    public double getPrecioBase() {
        return precioBase;
    }
    
    public void setPrecioBase(double precioBase) {
        this.precioBase = precioBase;
    }
    
    public String getEstado() {
        return estado;
    }
    
    public void setEstado(String estado) {
        this.estado = estado;
    }
}

