package Controlador;

import Modelos.Reserva;
import Modelos.SesionUsuario;
import Conexion.Conexion;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Date;
import java.util.List;
import java.util.ArrayList;
import javax.swing.JOptionPane;

public class ControladorReserva {
    
    /**
     * Crear una reserva sin asignar habitación específica
     */
    public static boolean crearReserva(String nombreCliente, String telefono, 
                                 Date fechaEntrada, Date fechaSalida) {
    try {
        // Buscar una habitación disponible automáticamente
        int habitacionDisponible = buscarPrimeraHabitacionDisponible(fechaEntrada, fechaSalida);
        
        if (habitacionDisponible > 0) {
            // Crear reserva CON habitación asignada
            String referenciaPago = generarReferencia();
            
            if (asignarHabitacion(habitacionDisponible, SesionUsuario.getUsuarioActual(), 
                                nombreCliente, telefono, fechaEntrada, fechaSalida, referenciaPago)) {
                mostrarInformacionPago(referenciaPago, nombreCliente);
                return true;
            }
        } else {
            JOptionPane.showMessageDialog(null, "No hay habitaciones disponibles para las fechas seleccionadas");
        }
        
    } catch (Exception e) {
        JOptionPane.showMessageDialog(null, "Error al crear reserva: " + e.getMessage());
    }
    
    return false;
}

// Agregar este método auxiliar
private static int buscarPrimeraHabitacionDisponible(Date fechaEntrada, Date fechaSalida) {
    Connection conn = null;
    try {
        Conexion conexion = new Conexion();
        conn = conexion.getConnection();
        
        String query = "SELECT h.id FROM habitaciones h " +
                      "WHERE h.estado = 'DISPONIBLE' " +
                      "AND h.id NOT IN (" +
                      "    SELECT r.habitacion_id FROM reservas r " +
                      "    WHERE r.habitacion_id IS NOT NULL " +
                      "    AND r.estado IN ('PENDIENTE', 'CONFIRMADA') " +
                      "    AND ((r.fecha_entrada <= ? AND r.fecha_salida >= ?) " +
                      "         OR (r.fecha_entrada <= ? AND r.fecha_salida >= ?) " +
                      "         OR (r.fecha_entrada >= ? AND r.fecha_entrada <= ?))) " +
                      "ORDER BY h.numero_habitacion LIMIT 1";
        
        PreparedStatement stmt = conn.prepareStatement(query);
        java.sql.Date sqlFechaEntrada = new java.sql.Date(fechaEntrada.getTime());
        java.sql.Date sqlFechaSalida = new java.sql.Date(fechaSalida.getTime());
        
        stmt.setDate(1, sqlFechaEntrada);
        stmt.setDate(2, sqlFechaEntrada);
        stmt.setDate(3, sqlFechaSalida);
        stmt.setDate(4, sqlFechaSalida);
        stmt.setDate(5, sqlFechaEntrada);
        stmt.setDate(6, sqlFechaSalida);
        
        ResultSet rs = stmt.executeQuery();
        if (rs.next()) {
            return rs.getInt("id");
        }
        
    } catch (SQLException e) {
        System.err.println("Error al buscar habitación disponible: " + e.getMessage());
    } finally {
        try {
            if (conn != null) conn.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
    
    return 0;
}
    
    /**
 * Crear reserva y actualizar estado de habitación automáticamente
 */
public static boolean crearReservaYActualizarHabitacion(String nombreCliente, String telefono, 
                                                       Date fechaEntrada, Date fechaSalida, int habitacionId) {
    Connection conn = null;
    try {
        Conexion conexion = new Conexion();
        conn = conexion.getConnection();
        conn.setAutoCommit(false); // Iniciar transacción
        
        // 1. Verificar disponibilidad una vez más
        if (!verificarDisponibilidadHabitacion(habitacionId, fechaEntrada, fechaSalida)) {
            JOptionPane.showMessageDialog(null, "La habitación ya no está disponible");
            return false;
        }
        
        // 2. Crear la reserva
        String referenciaPago = generarReferencia();
        String queryReserva = "INSERT INTO reservas (usuario_cliente, nombre_cliente, telefono, " +
                             "fecha_entrada, fecha_salida, referencia_pago, habitacion_id) VALUES (?, ?, ?, ?, ?, ?, ?)";
        
        PreparedStatement stmtReserva = conn.prepareStatement(queryReserva);
        stmtReserva.setString(1, SesionUsuario.getUsuarioActual());
        stmtReserva.setString(2, nombreCliente);
        stmtReserva.setString(3, telefono);
        stmtReserva.setDate(4, new java.sql.Date(fechaEntrada.getTime()));
        stmtReserva.setDate(5, new java.sql.Date(fechaSalida.getTime()));
        stmtReserva.setString(6, referenciaPago);
        stmtReserva.setInt(7, habitacionId);
        
        int filasReserva = stmtReserva.executeUpdate();
        
        if (filasReserva > 0) {
            // 3. Actualizar estado de habitación solo si la reserva está en las fechas actuales
            java.util.Date hoy = new java.util.Date();
            if (!fechaEntrada.after(hoy)) { // Si la fecha de entrada es hoy o antes
                String queryHabitacion = "UPDATE habitaciones SET estado = 'OCUPADA' WHERE id = ?";
                PreparedStatement stmtHabitacion = conn.prepareStatement(queryHabitacion);
                stmtHabitacion.setInt(1, habitacionId);
                stmtHabitacion.executeUpdate();
            }
            
            conn.commit(); // Confirmar transacción
            mostrarInformacionPago(referenciaPago, nombreCliente);
            return true;
        }
        
    } catch (SQLException e) {
        try {
            if (conn != null) conn.rollback(); // Revertir cambios en caso de error
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
        JOptionPane.showMessageDialog(null, "Error al crear reserva: " + e.getMessage());
    } finally {
        try {
            if (conn != null) {
                conn.setAutoCommit(true);
                conn.close();
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
    
    return false;
}
    
    /**
     * Crear una reserva con habitación específica asignada
     */
    public static boolean crearReservaConHabitacion(String nombreCliente, String telefono, 
                                                  Date fechaEntrada, Date fechaSalida, int habitacionId) {
        try {
            // Verificar si la habitación está disponible en las fechas seleccionadas
            if (!verificarDisponibilidadHabitacion(habitacionId, fechaEntrada, fechaSalida)) {
                JOptionPane.showMessageDialog(null, "La habitación no está disponible en las fechas seleccionadas");
                return false;
            }
            
            String referenciaPago = generarReferencia();
            
            if (asignarHabitacion(habitacionId, SesionUsuario.getUsuarioActual(), 
                                nombreCliente, telefono, fechaEntrada, fechaSalida, referenciaPago)) {
                mostrarInformacionPago(referenciaPago, nombreCliente);
                return true;
            }
            
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Error al crear reserva: " + e.getMessage());
        }
        
        return false;
    }
    
    /**
     * Obtener lista de habitaciones disponibles en un rango de fechas
     */
    public static List<Object[]> obtenerHabitacionesDisponibles(Date fechaEntrada, Date fechaSalida) {
        List<Object[]> habitacionesDisponibles = new ArrayList<>();
        Connection conn = null;
        
        try {
            Conexion conexion = new Conexion();
            conn = conexion.getConnection();
            
            String query = "SELECT h.id, h.numero_habitacion, h.tipo, h.capacidad, h.precio_por_noche, h.descripcion " +
                          "FROM habitaciones h " +
                          "WHERE h.estado = 'DISPONIBLE' " +
                          "AND h.id NOT IN (" +
                          "    SELECT r.habitacion_id FROM reservas r " +
                          "    WHERE r.habitacion_id IS NOT NULL " +
                          "    AND r.estado IN ('PENDIENTE', 'CONFIRMADA') " +
                          "    AND ((r.fecha_entrada BETWEEN ? AND ?) " +
                          "         OR (r.fecha_salida BETWEEN ? AND ?) " +
                          "         OR (r.fecha_entrada <= ? AND r.fecha_salida >= ?))) " +
                          "ORDER BY h.numero_habitacion";
            
            PreparedStatement stmt = conn.prepareStatement(query);
            java.sql.Date sqlFechaEntrada = new java.sql.Date(fechaEntrada.getTime());
            java.sql.Date sqlFechaSalida = new java.sql.Date(fechaSalida.getTime());
            
            stmt.setDate(1, sqlFechaEntrada);
            stmt.setDate(2, sqlFechaSalida);
            stmt.setDate(3, sqlFechaEntrada);
            stmt.setDate(4, sqlFechaSalida);
            stmt.setDate(5, sqlFechaEntrada);
            stmt.setDate(6, sqlFechaSalida);
            
            ResultSet rs = stmt.executeQuery();
            
            while (rs.next()) {
                Object[] habitacion = {
                    rs.getInt("id"),
                    rs.getString("numero_habitacion"),
                    rs.getString("tipo"),
                    rs.getInt("capacidad"),
                    rs.getDouble("precio_por_noche"),
                    rs.getString("descripcion")
                };
                habitacionesDisponibles.add(habitacion);
            }
            
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Error al obtener habitaciones disponibles: " + e.getMessage());
        } finally {
            try {
                if (conn != null) conn.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
        
        return habitacionesDisponibles;
    }
    
    /**
     * Verificar si una habitación está disponible en un rango de fechas
     */
    public static boolean verificarDisponibilidadHabitacion(int habitacionId, Date fechaEntrada, Date fechaSalida) {
        Connection conn = null;
        try {
            Conexion conexion = new Conexion();
            conn = conexion.getConnection();
            
            String query = "SELECT COUNT(*) FROM reservas " +
                          "WHERE habitacion_id = ? " +
                          "AND estado IN ('PENDIENTE', 'CONFIRMADA') " +
                          "AND ((fecha_entrada BETWEEN ? AND ?) " +
                          "     OR (fecha_salida BETWEEN ? AND ?) " +
                          "     OR (fecha_entrada <= ? AND fecha_salida >= ?))";
            
            PreparedStatement stmt = conn.prepareStatement(query);
            java.sql.Date sqlFechaEntrada = new java.sql.Date(fechaEntrada.getTime());
            java.sql.Date sqlFechaSalida = new java.sql.Date(fechaSalida.getTime());
            
            stmt.setInt(1, habitacionId);
            stmt.setDate(2, sqlFechaEntrada);
            stmt.setDate(3, sqlFechaSalida);
            stmt.setDate(4, sqlFechaEntrada);
            stmt.setDate(5, sqlFechaSalida);
            stmt.setDate(6, sqlFechaEntrada);
            stmt.setDate(7, sqlFechaSalida);
            
            ResultSet rs = stmt.executeQuery();
            if (rs.next()) {
                return rs.getInt(1) == 0; // Disponible si no hay conflictos
            }
            
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Error al verificar disponibilidad: " + e.getMessage());
        } finally {
            try {
                if (conn != null) conn.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
        
        return false;
    }
    
    /**
     * Obtener reservas de un usuario específico
     */
    public static List<Reserva> obtenerReservasUsuario(String usuario) {
        List<Reserva> reservas = new ArrayList<>();
        Connection conn = null;
        
        try {
            Conexion conexion = new Conexion();
            conn = conexion.getConnection();
            
            String query = "SELECT * FROM reservas WHERE usuario_cliente = ? ORDER BY fecha_reserva DESC";
            PreparedStatement stmt = conn.prepareStatement(query);
            stmt.setString(1, usuario);
            
            ResultSet rs = stmt.executeQuery();
            
            while (rs.next()) {
                Reserva reserva = new Reserva();
                reserva.setId(rs.getInt("id"));
                reserva.setUsuarioCliente(rs.getString("usuario_cliente"));
                reserva.setNombreCliente(rs.getString("nombre_cliente"));
                reserva.setTelefono(rs.getString("telefono"));
                reserva.setFechaEntrada(rs.getDate("fecha_entrada"));
                reserva.setFechaSalida(rs.getDate("fecha_salida"));
                reserva.setReferenciaPago(rs.getString("referencia_pago"));
                reserva.setEstado(rs.getString("estado"));
                reserva.setFechaReserva(rs.getTimestamp("fecha_reserva"));
                
                reservas.add(reserva);
            }
            
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Error al obtener reservas: " + e.getMessage());
        } finally {
            try {
                if (conn != null) conn.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
        
        return reservas;
    }
    
    /**
     * Actualizar estado de una reserva
     */
    public static boolean actualizarEstadoReserva(int reservaId, String nuevoEstado) {
        Connection conn = null;
        try {
            Conexion conexion = new Conexion();
            conn = conexion.getConnection();
            
            String query = "UPDATE reservas SET estado = ? WHERE id = ?";
            PreparedStatement stmt = conn.prepareStatement(query);
            stmt.setString(1, nuevoEstado);
            stmt.setInt(2, reservaId);
            
            int rowsAffected = stmt.executeUpdate();
            return rowsAffected > 0;
            
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Error al actualizar estado: " + e.getMessage());
            return false;
        } finally {
            try {
                if (conn != null) conn.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
    }
    
    /**
     * Cancelar una reserva
     */
    public static boolean cancelarReserva(int reservaId) {
        return actualizarEstadoReserva(reservaId, "CANCELADA");
    }
    
    // ===============================
    // MÉTODOS PRIVADOS AUXILIARES
    // ===============================
    
    /**
     * Generar referencia única de pago
     */
    private static String generarReferencia() {
        long timestamp = System.currentTimeMillis();
        return "REF" + String.valueOf(timestamp).substring(7);
    }
    
    /**
     * Guardar reserva sin habitación específica
     */
    private static boolean guardarReserva(Reserva reserva) throws SQLException {
        Connection conn = null;
        try {
            Conexion conexion = new Conexion();
            conn = conexion.getConnection();
            
            if (conn == null) {
                throw new SQLException("No se pudo conectar a la base de datos");
            }
            
            String query = "INSERT INTO reservas (usuario_cliente, nombre_cliente, telefono, " +
                          "fecha_entrada, fecha_salida, referencia_pago) VALUES (?, ?, ?, ?, ?, ?)";
            
            PreparedStatement stmt = conn.prepareStatement(query);
            stmt.setString(1, reserva.getUsuarioCliente());
            stmt.setString(2, reserva.getNombreCliente());
            stmt.setString(3, reserva.getTelefono());
            stmt.setDate(4, new java.sql.Date(reserva.getFechaEntrada().getTime()));
            stmt.setDate(5, new java.sql.Date(reserva.getFechaSalida().getTime()));
            stmt.setString(6, reserva.getReferenciaPago());
            
            int rowsAffected = stmt.executeUpdate();
            return rowsAffected > 0;
            
        } finally {
            if (conn != null) {
                conn.close();
            }
        }
    }
    
    /**
     * Asignar habitación específica a una reserva
     */
    private static boolean asignarHabitacion(int habitacionId, String usuarioCliente, String nombreCliente, 
                                           String telefono, Date fechaEntrada, Date fechaSalida, 
                                           String referenciaPago) throws SQLException {
        Connection conn = null;
        try {
            Conexion conexion = new Conexion();
            conn = conexion.getConnection();
            
            String query = "INSERT INTO reservas (usuario_cliente, nombre_cliente, telefono, " +
                          "fecha_entrada, fecha_salida, referencia_pago, habitacion_id) VALUES (?, ?, ?, ?, ?, ?, ?)";
            
            PreparedStatement stmt = conn.prepareStatement(query);
            stmt.setString(1, usuarioCliente);
            stmt.setString(2, nombreCliente);
            stmt.setString(3, telefono);
            stmt.setDate(4, new java.sql.Date(fechaEntrada.getTime()));
            stmt.setDate(5, new java.sql.Date(fechaSalida.getTime()));
            stmt.setString(6, referenciaPago);
            stmt.setInt(7, habitacionId);
            
            int rowsAffected = stmt.executeUpdate();
            return rowsAffected > 0;
            
        } finally {
            if (conn != null) {
                conn.close();
            }
        }
    }
    
    /**
     * Mostrar información de pago al cliente
     */
    private static void mostrarInformacionPago(String referencia, String nombreCliente) {
        String informacionPago = "═══════════════════════════════════════\n" +
                               "           REFERENCIA DE PAGO\n" +
                               "═══════════════════════════════════════\n\n" +
                               "Cliente: " + nombreCliente + "\n" +
                               "Referencia: " + referencia + "\n\n" +
                               "DATOS PARA TRANSFERENCIA:\n" +
                               "───────────────────────────────────────\n" +
                               "Banco: BBVA México\n" +
                               "Cuenta: 0123456789\n" +
                               "CLABE: 012345678901234567\n" +
                               "Beneficiario: Hotel RESERGO S.A. de C.V.\n" +
                               "Concepto: " + referencia + "\n" +
                               "Monto: $1,500.00 MXN\n\n" +
                               "IMPORTANTE:\n" +
                               "• Incluya la referencia en el concepto\n" +
                               "• La reserva se confirmará al recibir el pago\n" +
                               "• Conserve este comprobante\n" +
                               "• Para consultas: info@resergo.com\n" +
                               "• Teléfono: (951) 123-4567\n" +
                               "═══════════════════════════════════════";
        
        JOptionPane.showMessageDialog(null, informacionPago, "Información de Pago", JOptionPane.INFORMATION_MESSAGE);
        
        // Guardar comprobante en archivo
        guardarComprobanteEnArchivo(informacionPago, referencia);
    }
    
    /**
     * Guardar comprobante de pago en archivo de texto
     */
    private static void guardarComprobanteEnArchivo(String contenido, String referencia) {
        try {
            java.io.FileWriter archivo = new java.io.FileWriter("Comprobante_" + referencia + ".txt");
            archivo.write(contenido);
            archivo.close();
            
            JOptionPane.showMessageDialog(null, 
                "Comprobante guardado como: Comprobante_" + referencia + ".txt\n" +
                "Puede encontrarlo en la carpeta del proyecto.");
        } catch (java.io.IOException e) {
            JOptionPane.showMessageDialog(null, "Error al guardar el comprobante: " + e.getMessage());
        }
    }
    
    /**
     * Calcular costo total de una reserva
     */
    public static double calcularCostoReserva(int habitacionId, Date fechaEntrada, Date fechaSalida) {
        Connection conn = null;
        try {
            Conexion conexion = new Conexion();
            conn = conexion.getConnection();
            
            // Obtener precio por noche de la habitación
            String query = "SELECT precio_por_noche FROM habitaciones WHERE id = ?";
            PreparedStatement stmt = conn.prepareStatement(query);
            stmt.setInt(1, habitacionId);
            
            ResultSet rs = stmt.executeQuery();
            if (rs.next()) {
                double precioPorNoche = rs.getDouble("precio_por_noche");
                
                // Calcular número de noches
                long diferenciaMilisegundos = fechaSalida.getTime() - fechaEntrada.getTime();
                int numeroNoches = (int) (diferenciaMilisegundos / (1000 * 60 * 60 * 24));
                
                if (numeroNoches <= 0) {
                    numeroNoches = 1; // Mínimo una noche
                }
                
                return precioPorNoche * numeroNoches;
            }
            
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Error al calcular costo: " + e.getMessage());
        } finally {
            try {
                if (conn != null) conn.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
        
        return 0.0;
    }
    
    /**
     * Obtener información de habitación por ID
     */
    public static Object[] obtenerInfoHabitacion(int habitacionId) {
        Connection conn = null;
        try {
            Conexion conexion = new Conexion();
            conn = conexion.getConnection();
            
            String query = "SELECT numero_habitacion, tipo, capacidad, precio_por_noche, descripcion " +
                          "FROM habitaciones WHERE id = ?";
            PreparedStatement stmt = conn.prepareStatement(query);
            stmt.setInt(1, habitacionId);
            
            ResultSet rs = stmt.executeQuery();
            if (rs.next()) {
                return new Object[] {
                    rs.getString("numero_habitacion"),
                    rs.getString("tipo"),
                    rs.getInt("capacidad"),
                    rs.getDouble("precio_por_noche"),
                    rs.getString("descripcion")
                };
            }
            
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Error al obtener información de habitación: " + e.getMessage());
        } finally {
            try {
                if (conn != null) conn.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
        
        return null;
    }
}