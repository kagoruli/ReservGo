package Controlador;

import Modelos.Login;
import Modelos.SesionUsuario;
import Vistas.InicioSesion;
import Vistas.MenuAdmi;
import Vistas.MenuCliente;
import javax.swing.JOptionPane;
import java.sql.SQLException;

public class ControladorInicioSesion {
    
    public static void CrearLogin(InicioSesion sesion) {
    String nombre = sesion.usuario.getText();
    String contrasena = new String(sesion.contraseña.getPassword());
    String rol = sesion.getRolSeleccionado();
    
    // Validar campos vacíos
    if (nombre.trim().isEmpty() || nombre.equals("@Username")) {
        JOptionPane.showMessageDialog(null, "Por favor ingrese un nombre de usuario válido");
        return;
    }
    
    if (contrasena.trim().isEmpty() || contrasena.equals("jPasswordField2")) {
        JOptionPane.showMessageDialog(null, "Por favor ingrese una contraseña válida");
        return;
    }
    
    Login login = new Login(nombre, contrasena, rol);
    try {
        if (login.validarRegistro()) {
            // AGREGAR ESTA LÍNEA - Inicializar sesión del usuario
            SesionUsuario.iniciarSesion(nombre, rol);
            
            JOptionPane.showMessageDialog(null, "Bienvenido " + nombre + " (" + rol + ")");
            
            // Cerrar ventana actual
            sesion.dispose();
            
            // Abrir ventana según el rol
            if (rol.equals("ADMIN")) {
                new MenuAdmi().setVisible(true);
            } else {
                new MenuCliente().setVisible(true);
            }
            
        } else {
            JOptionPane.showMessageDialog(null, "Usuario o contraseña incorrectos");
        }
    } catch (SQLException e) {
        JOptionPane.showMessageDialog(null, "Error de conexión: " + e.getMessage());
    }
}
}
