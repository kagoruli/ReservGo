package Principal;
import Conexion.Conexion;
import Vistas.InicioSesion;

public class App {
    public static Conexion conexion = new Conexion();
    public static InicioSesion sesion = new InicioSesion();
    
    public static void main(String args[]){
      sesion.setVisible(true);
    }  
}
